# simpleFight
Simple fight game with basic attacks 
